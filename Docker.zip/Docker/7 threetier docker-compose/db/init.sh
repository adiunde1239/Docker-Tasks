echo 'i am inside shell script file'
