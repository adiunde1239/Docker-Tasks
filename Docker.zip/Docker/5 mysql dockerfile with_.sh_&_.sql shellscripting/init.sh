echo "This is inside shell script file"
