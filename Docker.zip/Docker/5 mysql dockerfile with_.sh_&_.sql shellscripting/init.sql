create database insta;
use insta;
create table users (id int, name varchar(10));
insert into users values (1,"Tejas"),(2,"Sushant");
